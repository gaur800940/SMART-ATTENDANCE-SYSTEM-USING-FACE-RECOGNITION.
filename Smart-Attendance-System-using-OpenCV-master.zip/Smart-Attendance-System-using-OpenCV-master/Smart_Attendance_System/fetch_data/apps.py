from django.apps import AppConfig


class FetchDataConfig(AppConfig):
    name = 'fetch_data'
