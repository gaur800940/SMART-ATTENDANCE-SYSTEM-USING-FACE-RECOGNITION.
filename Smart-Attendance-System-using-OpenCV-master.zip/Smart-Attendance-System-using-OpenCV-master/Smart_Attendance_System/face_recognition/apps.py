from django.apps import AppConfig


class FaceRecognitionConfig(AppConfig):
    name = 'face_recognition'
