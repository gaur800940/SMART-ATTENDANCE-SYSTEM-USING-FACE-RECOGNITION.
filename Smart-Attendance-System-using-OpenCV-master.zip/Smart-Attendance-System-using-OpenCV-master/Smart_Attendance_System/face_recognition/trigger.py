from .Face_Recognition import start as st


def start():
    st.start_training()
