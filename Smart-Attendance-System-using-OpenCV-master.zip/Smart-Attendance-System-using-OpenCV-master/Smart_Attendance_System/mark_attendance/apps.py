from django.apps import AppConfig


class MarkAttendanceConfig(AppConfig):
    name = 'mark_attendance'
