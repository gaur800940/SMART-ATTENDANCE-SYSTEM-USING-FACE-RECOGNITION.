from face_recognition.Face_Recognition import start as st


def start():
    st.start_check_image()


def start_camera_attendance():
    st.camera_attendance_start()
