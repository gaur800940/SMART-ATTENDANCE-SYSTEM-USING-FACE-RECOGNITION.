from django.apps import AppConfig


class TermsAndConditionsConfig(AppConfig):
    name = 'terms_and_conditions'
