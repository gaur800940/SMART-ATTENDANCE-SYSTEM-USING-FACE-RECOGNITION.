from django.apps import AppConfig


class PrivacyPolicyConfig(AppConfig):
    name = 'privacy_policy'
