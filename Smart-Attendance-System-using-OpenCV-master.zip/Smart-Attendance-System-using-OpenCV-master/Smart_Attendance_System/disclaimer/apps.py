from django.apps import AppConfig


class DisclaimerConfig(AppConfig):
    name = 'disclaimer'
