from django.apps import AppConfig


class AdminCpanelConfig(AppConfig):
    name = 'admin_cpanel'
